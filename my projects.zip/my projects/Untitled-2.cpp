#include<iostream>
using namespace std;
int main()
{
    int a[5]={12,23,21,11,9};
    int m=a[0];
    int i;
    int j;
    for( i=1; i<5; i++)
    {
        for( j=1; j<5-i; j++)
        {
            if(a[i]<m)
            {
                int t =a[i];
                a[i]=a[i+1];
                a[j+1]=t;

            }
           
    
            
        }
    }
     for(i=0; i<5; i++)
{cout<<a[i];
 }
}